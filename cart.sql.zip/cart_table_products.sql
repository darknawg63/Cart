
-- --------------------------------------------------------

--
-- Table structure for table `products`
--
-- Creation: Nov 01, 2016 at 02:16 PM
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `description` text,
  `price` float NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `stock` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Required by Eloquent',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Required by Eloquent'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELATIONS FOR TABLE `products`:
--

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `title`, `slug`, `description`, `price`, `image`, `stock`, `created_at`, `updated_at`) VALUES
(1, 'WOMEN\'S GOLF BIOM G2 ', 'womens-golf-biom-g2', 'The women\'s Golf Biom G2 is an extremely balanced light golfing shoe of top quality.', 149.99, 'http://placehold.it/350x150?text=Product+image', 88, '2016-11-01 14:22:52', NULL),
(2, 'SHAPE 25 ', 'shape-25', 'The Shape 25 is a high boot that flatters and accentuates a women\'s calves. Like a woman, the fit feels strong yet subtle.\r\n  ', 229.99, 'http://placehold.it/350x150?text=Product+image', 0, '2016-11-01 14:22:52', NULL),
(3, 'ELAINE ', 'elaine', 'The Ecco Elain is for the woman who\'s on the go. Not just a hiking boot, but also exceptional for every day use.', 139.99, 'http://placehold.it/350x150?text=Product+image', 78, '2016-11-01 14:22:52', NULL),
(4, 'UKIUK ', 'ukiuk', 'The UKIUK is a soft, casual, short boot for all occasions. No woman\'s wardrobe would be complete without them. ', 149.99, 'http://placehold.it/350x150?text=Product+image', 62, '2016-11-01 14:22:52', NULL),
(5, 'JAMESTOWN ', 'jamestown', 'Our Jamestown line supports the foot with its soft but firmly bolstered heel cup and extremely durable sole. ', 149.99, 'http://placehold.it/350x150?text=Product+image', 6, '2016-11-01 14:22:52', NULL),
(6, 'MEN\'S GOLF CAGE', 'mens-golf-cage', 'The men\'s Golf Cage is an extremely durable light golfing shoe of premium quality.', 179.99, 'http://placehold.it/350x150?text=Product+image', 44, '2016-11-01 14:22:53', NULL);
