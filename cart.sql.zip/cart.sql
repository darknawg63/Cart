-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 09, 2016 at 03:01 PM
-- Server version: 10.1.19-MariaDB-1~xenial
-- PHP Version: 7.0.8-0ubuntu0.16.04.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cart`
--
CREATE DATABASE IF NOT EXISTS `cart` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `cart`;

-- --------------------------------------------------------

--
-- Table structure for table `addresses`
--

DROP TABLE IF EXISTS `addresses`;
CREATE TABLE `addresses` (
  `id` int(11) UNSIGNED NOT NULL,
  `address1` varchar(255) NOT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `city` varchar(255) NOT NULL,
  `postal_code` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Required by Eloquent',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Required by Eloquent'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
CREATE TABLE `customers` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Required by Eloquent',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Required by Eloquent'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` int(11) UNSIGNED NOT NULL,
  `hash` varchar(255) NOT NULL,
  `total` float NOT NULL,
  `address_id` int(11) NOT NULL,
  `paid` tinyint(1) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Required by Eloquent',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Required by Eloquent'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `orders_products`
--

DROP TABLE IF EXISTS `orders_products`;
CREATE TABLE `orders_products` (
  `id` int(11) UNSIGNED NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Relates Orders to Products';

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

DROP TABLE IF EXISTS `payments`;
CREATE TABLE `payments` (
  `id` int(11) UNSIGNED NOT NULL,
  `order_id` int(11) NOT NULL,
  `failed` tinyint(1) NOT NULL,
  `transaction_id` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Required by Eloquent',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Required by Eloquent'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `description` text,
  `price` float NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `stock` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Required by Eloquent',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Required by Eloquent'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `title`, `slug`, `description`, `price`, `image`, `stock`, `created_at`, `updated_at`) VALUES
(7, 'Envivo Lungo', 'envivo-lungo', 'POTENT AND CARAMELIZED:  \r\n\r\nOrigin Envivo Lungo is a blend of green coffees from two origins, India and Mexico. Roasting The Arabica and the Robusta parts are roasted separately and dark to deliver high intensity with refined taste and a full body. The Robusta split is roasted longer and darker. Aromatic Profile A bold coffee, with caramelized notes reminiscent of aromatic woods and gingerbread. Served as a morning coffee, it offers a pleasant body and taste together with a high intensity.', 0.37, 'http://placehold.it/350x150?text=Product+image', 10, '2016-11-07 13:25:38', '2016-11-07 13:25:38'),
(8, 'Capriccio', 'capriccio', 'RICH AND DISTINCTIVE:  \r\n\r\nBlending South American Arabicas with a touch of Robusta, Capriccio is an espresso with a rich aroma and a strong typical cereal note. Origin The presence of South American Arabicas grown at high altitude gives this blend a light acidity, which is balanced with the perfect amount of Brazilian Arabica and a touch of Robusta. Roasting The light roasting of this blend creates a rich character and preserves a light acidity. Aromatic Profile A typical cereal note balanced with a light acidity.   Discover the Espresso range', 0.35, 'http://placehold.it/350x150?text=Product+image', 10, '2016-11-07 13:25:38', NULL),
(9, 'Cosi', 'cosi', 'MILD AND DELICATELY TOASTED:  \r\n\r\nPure Arabicas from East Africa, Central and South America make this coffee a delicate and balanced blend with cereal and lightly toasted notes enhanced by subtle fruity notes. Origin Arabicas from Costa Rica give this blend its characteristic cereal and lightly toasted notes, while the finest Arabicas from Kenya bring out its delicate fruity notes, both harmonised by Latin American Arabicas. Roasting A light roasting, perfectly executed by the Nespresso Master Roasters, creates a delicate and balanced marriage of lightly toasted cereal and fruity notes. Aromatic Profile Mild cereal and lightly toasted notes enhanced by subtle fruity notes  Discover the Espresso range', 0.35, 'http://placehold.it/350x150?text=Product+image', 10, '2016-11-07 13:43:07', NULL),
(10, 'Volluto', 'volluto', 'SWEET AND LIGHT:  \r\n\r\nA blend of pure and lightly roasted Arabica from South America, Volluto reveals sweet and biscuity flavours, reinforced by a little acidity and a fruity note. Origin The Brazilian and Colombian Arabicas that go into making Volluto come from small plantations that produce very high quality coffee. They are grown in respect of the environment and local traditions. Roasting Light roasting preserves the cereal note of the Brazilian Arabica and the fresh and fruity note of the Colombian coffee. Aromatic Profile Quite present and diverse: fruity notes harmoniously balanced with sweet and biscuity notes.  Discover the Espresso range', 0.35, 'http://placehold.it/350x150?text=Product+image', 10, '2016-11-07 13:43:07', NULL),
(11, 'Livanto', 'livanto', 'ROUND AND BALANCED:  \r\n\r\nA blend of pure Arabica from South and Central America, Livanto is a well-balanced espresso characterised by roasted caramalised notes. Origin This blend is composed of the most prestigious Central and South American Arabicas, found in Costa Rica and Colombia and is cultivated according to traditional methods to preserve their malted and fruity profiles. Roasting A medium roasting, accentuates malted notes, whilst fruity notes evolve to create a complex and delicate caramelised bouquet. Aromatic Profile A round and balanced profile, typical of freshly roasted coffee results in a combination of cereal, malted and caramelised notes as well as fine fruity notes.  Discover the Espresso range', 0.35, 'http://placehold.it/350x150?text=Product+image', 10, '2016-11-07 13:45:05', NULL),
(12, 'Ristretto', 'ristretto', 'POWERFUL AND CONTRASTING:  \r\n\r\nA blend of South American and East African Arabicas, with a touch of Robusta, roasted separately to create the subtle fruity note of this full-bodied, intense espresso. Origin Composed of some of the best South \r\nPOWERFUL AND CONTRASTING: \r\nAmerican Arabicas from sources such as Colombia and Brazil, Ristretto also contains the great, lightly acidic East African Arabicas and a touch of Robusta for added zing. Roasting The beans are roasted slowly and separately to obtain an original bouquet bringing together acidic, fruity, and roasted notes. Its finely ground texture creates an Italian-style coffee: intense, with a rich flavour and full body. Aromatic Profile Strong roasted notes softened by notes of chocolate. A subtle contrast between strength and bitterness, acidic and fruity notes.  Discover the Intenso range', 0.35, 'http://placehold.it/350x150?text=Product+image', 10, '2016-11-07 13:50:25', NULL),
(13, 'Linizio Lungo', 'linizio-lungo', 'ROUND AND SMOOTH:\r\n\r\nMild and well-rounded on the palate, Linizio Lungo is a blend of fine Arabicas enhancing malt and cereal notes. Origin Arabicas from Brazil and Colombia that go into making Linizio Lungo are handpicked. Treated differently, the Brazil Bourbon beans are washed, then depulped, and dried in the sun with their mucilage; the Arabica from Colombia on the other hand will be fermented with its mucilage and washed afterwards. Roasting The split roasting reveals the specificities of each origin. On one hand, longer roasting yields a darker bean that reveals the malted cereal notes of the Bourbon beans. On the other hand, shorter roasting of the Arabica from Colombia yields lighter beans and highlights the softer notes reminding of sugar cane, specific to its region of origin. Aromatic Profile Cereal.   Discover the Lungo range ', 0.37, 'http://placehold.it/350x150?text=Product+image', 10, '2016-11-07 13:50:25', NULL),
(14, 'Ciocattino', 'ciocattino', 'CHOCOLATE FLAVOURED:  \r\n\r\nDark and bitter chocolate notes meet the caramelized roast of the Livanto Grand Cru. A rich combination reminiscent of a square of dark chocolate. Origin This blend is composed of the most prestigious Central and South American Arabicas, found in Costa Rica and Colombia and is cultivated according to traditional methods to preserve their malted and fruity profiles. Roasting A medium roasting, accentuates malted notes, whilst fruity notes evolve to create a complex and delicate caramelised bouquet. Aromatic Profile A round and balanced profile, typical of freshly roasted coffee results in a combination of cereal, malted and caramelised notes as well as fine fruity notes. ', 0.42, 'http://placehold.it/350x150?text=Product+image', 5, '2016-11-07 13:59:58', NULL),
(15, 'Vanilio', 'vanilio', 'VANILLA FLAVOURED:  \r\n\r\nA balanced harmony between the rich and the velvety aromas of vanilla and the mellow flavour of the Livanto Grand Cru. A blend distinguished by its full flavour, infinitely smooth and silky on the palate. Origin This blend is composed of the most prestigious Central and South American Arabicas, found in Costa Rica and Colombia and is cultivated according to traditional methods to preserve their malted and fruity profiles. Roasting A medium roasting, accentuates malted notes, whilst fruity notes evolve to create a complex and delicate caramelised bouquet. Aromatic Profile A round and balanced profile, typical of freshly roasted coffee results in a combination of cereal, malted and caramelised notes as well as fine fruity notes.', 0.42, 'http://placehold.it/350x150?text=Product+image', 0, '2016-11-07 13:59:58', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addresses`
--
ALTER TABLE `addresses`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `EMAIL` (`email`),
  ADD UNIQUE KEY `NAME` (`name`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders_products`
--
ALTER TABLE `orders_products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `PRODUCTS` (`title`),
  ADD UNIQUE KEY `SLUG` (`slug`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addresses`
--
ALTER TABLE `addresses`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `orders_products`
--
ALTER TABLE `orders_products`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
