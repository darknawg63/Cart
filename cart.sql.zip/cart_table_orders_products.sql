
-- --------------------------------------------------------

--
-- Table structure for table `orders_products`
--
-- Creation: Nov 01, 2016 at 01:22 PM
--

DROP TABLE IF EXISTS `orders_products`;
CREATE TABLE `orders_products` (
  `id` int(11) UNSIGNED NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COMMENT='Relates Orders to Products';

--
-- RELATIONS FOR TABLE `orders_products`:
--
