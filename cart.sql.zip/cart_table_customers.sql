
-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
CREATE TABLE `customers` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Required by Eloquent',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Required by Eloquent'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `customers`
--

TRUNCATE TABLE `customers`;