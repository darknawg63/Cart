
-- --------------------------------------------------------

--
-- Table structure for table `customers`
--
-- Creation: Nov 01, 2016 at 02:17 PM
--

DROP TABLE IF EXISTS `customers`;
CREATE TABLE `customers` (
  `id` int(11) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Required by Eloquent',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Required by Eloquent'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELATIONS FOR TABLE `customers`:
--
