
-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders` (
  `id` int(11) UNSIGNED NOT NULL,
  `hash` varchar(255) NOT NULL,
  `total` float NOT NULL,
  `address_id` int(11) NOT NULL,
  `paid` tinyint(1) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Required by Eloquent',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Required by Eloquent'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Truncate table before insert `orders`
--

TRUNCATE TABLE `orders`;